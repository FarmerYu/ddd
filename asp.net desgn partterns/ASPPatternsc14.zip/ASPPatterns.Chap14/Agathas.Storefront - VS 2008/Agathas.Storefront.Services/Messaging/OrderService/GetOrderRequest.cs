﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Agathas.Storefront.Services.Messaging.OrderService
{
    public class GetOrderRequest
    {
        public int OrderId { get; set; }
    }

}
