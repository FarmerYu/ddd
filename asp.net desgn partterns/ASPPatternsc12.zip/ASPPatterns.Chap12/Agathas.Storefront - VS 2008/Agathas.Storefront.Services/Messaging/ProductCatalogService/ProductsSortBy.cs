﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Agathas.Storefront.Services.Messaging.ProductCatalogService
{
    public enum ProductsSortBy
    {
        PriceHighToLow = 1,
        PriceLowToHigh = 2
    }
}
