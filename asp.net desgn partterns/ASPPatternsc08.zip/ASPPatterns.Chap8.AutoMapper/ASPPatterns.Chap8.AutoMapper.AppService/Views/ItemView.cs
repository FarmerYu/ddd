﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASPPatterns.Chap8.AutoMapper.AppService.Views
{
    public class ItemView
    {
        public string ProductName { get; set; }
        public int Qty { get; set; }
    }
}
