﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASPPatterns.Chap7.Library.Infrastructure.Query
{
    public static class NamedQueryFactory
    {
        // No complex queries have been defined in this sample.
    }
}
