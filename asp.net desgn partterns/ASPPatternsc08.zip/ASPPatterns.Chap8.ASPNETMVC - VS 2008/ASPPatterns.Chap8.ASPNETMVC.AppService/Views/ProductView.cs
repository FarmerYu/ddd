﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASPPatterns.Chap8.ASPNETMVC.AppService.Views
{
    public class ProductView
    {
        public string Name { get; set; }
        public string Price { get; set; }
        public string Id { get; set; }
    }
}
