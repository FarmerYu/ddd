﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASPPatterns.Chap8.AutoMapper.Model
{
    public class Product
    {
        public string Name { get; set; }
    }
}
