﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Agathas.Storefront.Services.ViewModels
{
    public enum RefinementGroupings
    {
        brand = 1,
        size = 2,
        color = 3
    }
}
