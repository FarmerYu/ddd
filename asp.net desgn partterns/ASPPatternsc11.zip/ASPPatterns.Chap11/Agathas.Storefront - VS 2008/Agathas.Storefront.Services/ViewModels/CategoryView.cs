﻿
namespace Agathas.Storefront.Services.ViewModels
{
    public class CategoryView
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
