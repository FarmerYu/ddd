﻿using System;
namespace ASPPatterns.Chap8.MVP.Presentation
{
    public interface IBasketPresenter
    {
        void Display();
    }
}
