﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Agathas.Storefront.Controllers.ViewModels
{
    public class BasketSummaryView
    {
        public int NumberOfItems { get; set; }
        public string BasketTotal { get; set; }
    }
}
