﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASPPatterns.Chap7.Library.Infrastructure.Query
{
    public enum QueryName
    {       
        Dynamic = 0,
        RetrieveOrdersUsingAComplexQuery = 1
    }
}
