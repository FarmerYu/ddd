﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Agathas.Storefront.Services.ViewModels
{
    public class DeliveryOptionView
    {
        public int Id { get; set; }
        public string ShippingServiceDescription { get; set; }
    }

}
