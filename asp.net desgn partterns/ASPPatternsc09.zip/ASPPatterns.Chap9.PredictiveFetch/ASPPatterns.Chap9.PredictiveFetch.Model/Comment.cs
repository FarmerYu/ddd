﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASPPatterns.Chap9.PredictiveFetch.Model
{
    public class Comment
    {        
        public string Text { get; set; }
    }
}
