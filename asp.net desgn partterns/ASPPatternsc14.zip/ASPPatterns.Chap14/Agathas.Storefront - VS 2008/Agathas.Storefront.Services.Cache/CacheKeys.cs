﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Agathas.Storefront.Services.Cache
{
    public enum CacheKeys
    {
        TopSellingProducts,
        ProductDetail,
        AllProductTitles,
        AllProducts,
        AllCategories
    }
}
