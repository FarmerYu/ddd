﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ASPPatterns.Chap8.FrontController.Controller.Storage
{
    public enum ViewStorageKeys
    {
        Categories,
        Category,
        Products,
        Product
    }
}
