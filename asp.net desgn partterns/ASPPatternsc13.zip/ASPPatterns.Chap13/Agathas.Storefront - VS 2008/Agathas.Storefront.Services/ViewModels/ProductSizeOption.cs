﻿
namespace Agathas.Storefront.Services.ViewModels
{
    public class ProductSizeOption
    {
        public int Id { get; set; }
        public string SizeName { get; set; }
    }

}
